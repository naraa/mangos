﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EventAI
{
    public struct CreatureInfo
    {
        public static int    Id;
        public static string Name;
        public static string Description;
        public static string Name_loc;
        public static string Description_loc;
    }
}
