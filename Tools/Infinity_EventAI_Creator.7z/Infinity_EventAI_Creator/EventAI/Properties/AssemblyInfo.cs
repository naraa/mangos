﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// Managing general information about the assembly by using 
// set of attributes. Change the value of these attributes to change the information
// associated with the assembly.
[assembly: AssemblyTitle("EventAI Designer")]
[assembly: AssemblyDescription("The program for creating scripts EventAI.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Author Program: Konctantin & fallenangelX & singlem")]
[assembly: AssemblyProduct("EventAI Designer")]
[assembly: AssemblyCopyright("Copyright ©  2009 - 2011")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// ComVisible parameter with a value of FALSE makes the types in an assembly not visible 
// for COM-components. If you want to apply to type in this assembly through 
// COM, set the attribute ComVisible TRUE for this type
[assembly: ComVisible(false)]

// The following GUID is used to identify the type library if the project will be visible to COM
[assembly: Guid("c32357f6-6b03-4b49-aa3c-97772c4133c3")]

// Information about the version of the assembly consist of the following four values
//
//      The major version number
//      Minor version number 
//      Build Number
//      Edition
//
// You can specify all the values or accept the build number and revision number by default, 
// Using "*" as shown below:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.9.7.0")]
[assembly: AssemblyFileVersion("1.9.7.0")]
